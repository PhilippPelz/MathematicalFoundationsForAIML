# Mathematical Foundations of AI & ML

| Week | MFML – Mathematical Foundations | ML-PC – ML in Materials Processing & Characterization | MG – Materials Genomics | Exercise (90 min, Python-based) |
|---|---|---|---|---|
| 1 | Data as vectors, models, feature spaces | What counts as data in processing & characterization | What counts as data in materials databases | NumPy arrays, vector operations, plotting simple datasets |
| 2 | Data types, scales, normalization, units | Sensors, signals, images as arrays | Descriptors, compositions, metadata | Scaling & normalization effects; visual comparison |
| 3 | Probability, expectation, variance, noise | Measurement noise in experiments | Noise & uncertainty in databases | Monte Carlo sampling, simulate noisy measurements |
| 4 | Sampling, Nyquist, FFT as representation change | Signal preprocessing (spectra, time series) | Property distributions & statistics | FFT on synthetic signals; filtering |
| 5 | Linear regression, least squares (geometry) | Regression for process/property modeling | Correlation analysis in materials data | Implement linear regression from scratch |
| 6 | SVD & PCA (eigenvectors, variance) | PCA on spectra & micrographs | PCA & embeddings for materials spaces | PCA on high-dimensional dataset, visualize components |
| 7 | Loss functions, gradients, sensitivity | Model tuning & objective functions | Descriptor relevance & feature selection | Manual gradient descent on toy problems |
| 8 | Optimization, regularization (L1/L2) | Model robustness & stability | High-dimensional regression challenges | Compare regularization strengths |
| 9 | Neurons, activations, backpropagation | NN regression/classification for properties | NN for structure–property mapping | Tiny neural net: forward + backward pass |
| 10 | Capacity, overfitting, generalization | CNNs for images (conceptual math only) | Representation learning (conceptual) | Framework NN (PyTorch/Keras), overfitting demo |
| 11 | Autoencoders & latent variables | Anomaly detection in processes | Latent materials spaces & clustering | Train autoencoder, visualize latent space |
| 12 | Unsupervised learning & uncertainty intro | Drift & anomaly detection | Discovery in latent space | Clustering + uncertainty estimation |
| 13 | Physics-informed ML, explainability | Physics-informed constraints in ML | Trust, interpretability, causality | Sensitivity analysis, simple PINN demo |
| 14 | Integration, limits, outlook | Integrated case studies | Discovery limits & ethics | Mini end-to-end project / synthesis |
